﻿// See https://aka.ms/new-console-template for more information
using System;

namespace CHATBOT
{
    class Program
    {
        static void Main(string[] args)
        {
            //Chatbot should greet the user using a recorded message
            Console.WriteLine("Hello! I am a chatbot. What is your name?");
            string name = Console.ReadLine();
            Console.WriteLine("Hello " + name + "! How can I help you today?");
            //Decoration Code is kinda bland
            Console.ForegroundColor = ConsoleColor.Green;  // Make text green
            Console.WriteLine("I am here to help you with any questions you may have.");
            Console.ResetColor();  // Reset text color to default


            //Create a image for the chatbot that ASCII art it must say "Cybersecurity Awareness Chatbot"
            // Console.WriteLine("____ ___  _ ____  _____ ____  ____  _____ ____  _     ____  _  _____ ___  _   ____  _      ____  ____  _____ _      _____ ____  ____    ____  _     ____  _____  ____  ____  _____ \r\n");
           // Console.WriteLine("/   _\\ \\///  _ \\/  __//  __\\/ ___\\/  __//   _\\/ \\ /\\/  __\\/ \\/__ __\\\\  \\//  /  _ \\/ \\  /|/  _ \\/  __\\/  __// \\  /|/  __// ___\\/ ___\\  /   _\\/ \\ /|/  _ \\/__ __\\/  _ \\/  _ \\/__ __\\\r\n");
           // Console.WriteLine("|  /   \\  / | | //|  \  |  \\/||    \\|  \\  |  /  | | |||  \\/|| |  / \\   \\  /   | / \\|| |  ||| / \\||  \\/||  \\  | |\\ |||  \\  |    \\|    \\  |  /  | |_||| / \\|  / \\  | | //| / \\|  / \\  ");
           // Console.WriteLine("|  \ / /  | |_\  \\_ |    /\\___ ||  /_ |  \\_ | \\_/||    /| |  | |   |  \\   | \\_/|| |\\ ||| \\_/||    /|  /_ | | \\|||  /_ \\___ |\\___ |  |  \\_ | | ||| \\_/|  | |  | |_\\| | |  | |  ");
            //Console.WriteLine("\____//_/   \\____/\\____\\\\_/\\_\\____/\\____\\\\____/\\____/\\_/  \\_/\\_/  \\_/   \\__//   \\____/\\_/ \\|\\____/\\_/\\_\\\\____\\\\_/  \\|\\____\\\\____/\\____/\\____/  \\____/\\____/  \\_/  \\____/\\_/  \\_/  ");
            //Chatbot should retrieve ASCII art from a file and display it to the user
            //The name of the file is "asciiart.txt"
            //string asciiArt = System.IO.File.ReadAllText("ascii-text-art");
            //Basic Response System `using if else statements
            //if the user says "How Are You?" the chatbot should respond with "I am doing well, thank you for asking"
            string userResponse = Console.ReadLine();
            //CASE SENSITIVE code
            string userResponseLower = userResponse.ToLower(); // Convert user input to lowercase for case-insensitive comparison

            switch (userResponse)
            {
                case "how are you?":
                    Console.WriteLine("I am doing well, thank you for asking.");
                    break;
                case "what is your purpose?":
                    Console.WriteLine("I am here to help you with any questions you may have.");
                    break;
                case "what is a good password?":
                    Console.WriteLine("A good password is strong, long, and unique.");
                    break;
                case "what is phishing?":
                    Console.WriteLine("Phishing is a scam where attackers steal personal information.");
                    break;
                case "how can i browse the internet safely?":
                    Console.WriteLine("Use strong passwords, enable 2FA, and avoid suspicious links.");
                    break;
                case "goodbye":
                    Console.WriteLine("Goodbye! Stay safe.");
                    return;
                default:
                    Console.WriteLine("I'm sorry, I do not understand.");
                    break;
            }


            //Rememeber to make it so that regardless of iput and ouput the chatbot does not end until the user says "Goodbye"..... GitHub Comment

            //Don't forget to make the project colorful and fun...GitHub Comment


        }

    }
}



